<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'roofbag_livechatapp');
define('DB_USER', 'MobDev');
define('DB_PASS', 'tH49P2!@');

$table_prefix =  'livehelp_';

return true;

?>