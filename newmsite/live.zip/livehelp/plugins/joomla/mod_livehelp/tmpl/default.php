<?php 
defined('_JEXEC') or die('Restricted access');
?>
<!-- stardevelop.com Live Help International Copyright - All Rights Reserved //-->
<!-- BEGIN Live Help HTML Code - NOT PERMITTED TO MODIFY IMAGE MAP/CODE/LINKS //-->
<a href="#" class="LiveHelpButton"><img src="<?php echo($params->get('url', '/livehelp/')); ?>include/status.php" id="LiveHelpStatus" name="LiveHelpStatus" class="LiveHelpStatus" border="0" alt="Live Help" title="Live Help"/></a>
<!-- END Live Help HTML Code - NOT PERMITTED TO MODIFY IMAGE MAP/CODE/LINKS //-->